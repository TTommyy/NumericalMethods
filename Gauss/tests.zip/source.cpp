// Author XX
#include "vectalg.h"
Vector solveEquations(
        const Matrix & A0,
        const Vector & b,
        double  eps
){
    return b;
}


